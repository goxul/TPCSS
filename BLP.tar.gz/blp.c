#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>


int main(int argc, char **argv)
{
    const char *secretfile = "/root/ques_blp/secretdir/secret.txt";
    const char *publicfile = "/root/ques_blp/publicdir/public.txt";
    int pid1, pid2; 

    pid1 = fork();

    if (pid1 > 0)  
    {   // Parent process
        fprintf(stderr,"parent> Parent spawned SecretChild Process\n");
        
        pid2 = fork();
        
        if (pid2 > 0) { // Again, parent process.
          fprintf(stderr,"parent> Parent spawned PublicChild Process\n");
        }
        else { 
          // PublicChild process, spawned by the parent process.
          fprintf(stderr,"publicchild> In PublicChild Process\n");
        }
    } 
    else { 
      // SecretChild process, spawned by the parent process.
      fprintf(stderr,"secretchild> In SecretChild Process\n");
    }

    return 0;
}
